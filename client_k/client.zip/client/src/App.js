import './App.css';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import Home from './components/Home';
import Fruit from './components/Fruit';
import Vegetable from './components/Vegetable';
import Staple from './components/Staple';
import Sellers from './components/Sellers'
import Header from './components/Header';
import Footer from './components/Footer';
import Portfolio from './components/Portfolio';

function App() {
  return (
    // <BrowserRouter>
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/fruit" element={<Fruit />} />
        <Route path="/vegetable" element={<Vegetable />} />
        <Route path="/staple" element={<Staple />} />
        <Route path='/seller' element={<Sellers />}></Route>
        <Route path="/portfolio/:shopno" element={<Portfolio />} />
      </Routes>
      {/* <Footer /> */}
    </div>
  );
}

export default App;