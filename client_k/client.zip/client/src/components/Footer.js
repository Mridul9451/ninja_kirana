import React from 'react'
import "./footer.css";

const footer = () => {
  return (
    <div id="footer" className="mx-auto">
                    <a style={{ color: "white",}} href='https://zwdaeqp22ov.typeform.com/NinjaKirana?utm_source=via%20catalogue'>Apply Now - To Avail Credit</a>
    </div>
  )
}

export default footer
