import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import "./home.css";
import fruits from './images/fruits1.png';
import vegetables from './images/vegetables1.png';
import staple from './images/staples1.png';
import rupee from './images/rupee-circle.png';
import sellerslist from './images/sellerslist.png';
import arrowright from './images/arrowright.png';
import Footer from './Footer';

// import { forwardRef, useState } from "react";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import './Date.css'

// let ans;
// let dd, mm, yy;

// for current data
// const date = new Date();
// console.log(date);
// dd = date.getDate().toString();
// mm = date.getMonth();
// yy = date.getFullYear().toString();
// var dmy = mm + "/" + dd + "/" + yy;

const Home = () => {
    const navigate = useNavigate();
    const navigateToFruit = () => {
        navigate('/fruit');
    };
    const navigateToVegetable = () => {
        navigate('/vegetable');
    };
    const navigateToStaple = () => {
        navigate('/staple');
    };
    // const [startDate, setStartDate] = useState();
    // const ExampleCustomInput = forwardRef(({ value, onClick, onChange }, ref) => (
    //     <input
    //         type="text"
    //         placeholder="MM/DD/YYYY"
    //         value={value}
    //         className="example-custom-input"
    //         onClick={onClick}
    //         onChange={onChange}
    //         ref={ref}
    //     ></input>
    // ));
    // ans = startDate;

    // if (startDate !== undefined) {
    //     dd = ans.getDate().toString();
    //     mm = ans.getMonth();
    //     yy = ans.getFullYear().toString();
    // }

    const [companyData, setCompanyData] = useState(new Map());
    useEffect(() => {
        async function fetchData() {
            // someVarName = localStorage.getItem("date");
            const myMap = new Map();
            const response = await fetch(`https://ninja-kirana.onrender.com/items/all/all`);
            const data = await response.json();
            for (let i = 0; i < data.length; i++) {
                // if (data[i][2] === someVarName) {
                const key1 = data[i][1];
                if (data[i][7] === "Vegetable") {
                    data[i][7] = "Vegetables";
                }
                let matrix1 = [[data[i][2]], [data[i][7]]];
                const keyExists = myMap.has(key1);
                if (keyExists) {
                    const matrix2 = myMap.get(key1);
                    let c = 0;
                    for (let j = 0; j < matrix2[1].length; j++) {
                        if (matrix2[1][j] === matrix1[1][0]) {
                            c = 1;
                        }
                    }
                    if (c === 0) {
                        const mat = [[data[i][2]], matrix2[1].concat(matrix1[1])];
                        myMap.delete(key1);
                        myMap.set(key1, mat);
                    }
                }
                else {
                    myMap.set(key1, matrix1);
                }
                if (myMap.size > 2) {
                    break;
                }
                // }
            }
            myMap.delete("Vendor Name");
            setCompanyData(myMap);
            // console.log(myMap);
        }
        fetchData();
    }, []);

    return (
        <div>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"></link>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
            <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'></link>
            <div className="my-body">
                <p style={{ fontSize: "1.625rem", fontFamily: "Poppins" }}>Aurangabad Mandi Traders &<br /> Daily Live Prices</p>
                <div style={{
                    fontWeight: 600,
                    fontSize: "1.625rem",
                    paddingLeft: 8,
                    color: "black",
                    // backgroundImage: `url(${headerimg2})`,
                    height: "10vh",
                    margin: 0,
                    display: 'block',
                    backgroundRepeat: "repeat-x"
                }} className="d-flex align-items-center w-100 ninja">&nbsp;<img style={{ height: "2.5rem" }} src={rupee} alt="logo" />
                    &nbsp;<p style={{ paddingTop: 10, fontFamily: "Poppins" }}>Daily Prices</p>
                </div>

                <div className='conte'><p style={{ fontSize: "1.625rem", fontFamily: "Poppins" }} >Select the Category for the latest price</p></div>

                {/* <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    customInput={<ExampleCustomInput />}
                    dayClassName={() => "example-datepicker-day-class"}
                    popperClassName="example-datepicker-class"
                    todayButton="TODAY"
                /> */}

                <div>

                    <div>
                        {/* <div className="item"><Link to="/fruit" style={ans ? null : { pointerEvents: "none" }}><img src={fruits} className="myimage" alt="fruits" /></Link></div>
                <div className="item"><Link to="/vegetable" style={ans ? null : { pointerEvents: "none" }}><img src={vegetables} className="myimage" alt="vegetables" /></Link></div>
                <div className="item"><Link to="/staple" style={ans ? null : { pointerEvents: "none" }}><img src={staple} className="myimage" alt="staples" /></Link></div> */}

                        {/* <div className="item column"><Link onClick={() => navigateToFruit()} to="/fruit" style={ans ? null : { pointerEvents: "none" }}><img src={fruits} className="myimage" alt="fruits" style={{ height: "100px", width: "100px", paddingLeft: "10px", }} /></Link></div>
                        <div className="item column"><Link onClick={() => navigateToVegetable()} to="/vegetable" style={ans ? null : { pointerEvents: "none" }}><img src={vegetables} className="myimage" alt="vegetables" style={{ height: "100px", width: "100px", }} /></Link></div>
                        <div className="item column"><Link onClick={() => navigateToStaple()} to="/staple" style={ans ? null : { pointerEvents: "none" }}><img src={staple} className="myimage" alt="staples" style={{ height: "100px", width: "100px", paddingRight: "10px", }} /></Link></div> */}

                        <div className="item column"><Link onClick={() => navigateToFruit()} to="/fruit"><img src={fruits} className="myimage" alt="fruits" style={{ height: "100px", width: "110px", paddingLeft: "10px" }} /></Link></div>
                        <div className="item column"><Link onClick={() => navigateToVegetable()} to="/vegetable"><img src={vegetables} className="myimage" alt="vegetables" style={{ height: "100px", width: "100px", }} /></Link></div>
                        <div className="item column"><Link onClick={() => navigateToStaple()} to="/staple"><img src={staple} className="myimage" alt="staples" style={{ height: "100px", width: "110px", paddingRight: "10px", }} /></Link></div>

                    </div>

                    <div style={{
                        fontWeight: 600,
                        fontSize: "1.625rem",
                        paddingLeft: 8,
                        color: "black",
                        // backgroundImage: `url(${headerimg2})`,
                        height: "10vh",
                        margin: 0,
                        display: 'block',
                        backgroundRepeat: "repeat-x"
                    }} className="d-flex align-items-center w-100 ninja">&nbsp;<img style={{ height: "2.5rem" }} src={sellerslist} alt="logo" />
                        &nbsp;<p style={{ paddingTop: 10, fontFamily: "Poppins" }}>Sellers on ninja Kirana</p>
                    </div>

                    <div className='container-fluid'>
                        {Array.from(companyData).map(([companyName, productDetails]) => (

                            <div className="row" style={{ fontFamily: "Poppins", paddingLeft: 0, paddingRight: 0, marginBottom: "10px" }}>

                                <div className="col-xs-5 col-sm-4 col-lg-6">
                                    <p style={{ lineHeight: "1rem", fontSize: "1rem", fontWeight: "600", paddingTop: "15px", textAlign: "left" }}>{companyName}</p>
                                    <p style={{ lineHeight: "1rem", fontSize: "1rem", fontWeight: "600", textAlign: "left" }}>Shop No. {productDetails[0]}</p>
                                </div>

                                <div className="col-xs-3 col-sm-2 col-lg-2">
                                    <p style={{ fontSize: "1rem", fontWeight: "600" }}>
                                        {productDetails[1][0]} {productDetails[1][1]}
                                    </p>
                                </div>

                                <div className="col-xs-4 col-sm-6 col-lg-4">
                                    <Link to={`/portfolio/${productDetails[0]}`}>
                                        <p style={{ fontSize: "1rem", textAlign: "right", color: "black", fontWeight: 600 }}>
                                            <span style={{ textDecoration: "underline" }}>Know More</span>
                                            &nbsp;&nbsp;
                                            <img style={{ height: "1.5rem" }} src={arrowright} alt='arrowright'></img>
                                        </p>
                                    </Link>
                                </div>

                                {/* <div className="item column"><Link><p style={{ color: "black", textDecoration: "underline", fontSize: "1.2rem", fontWeight: "700" }}>Know More  <img style={{ height: "1.5rem" }} src={arrowright} alt="logo" /></p></Link></div> */}

                            </div>
                        ))}

                        <div><Link to="/seller"><p style={{ fontSize: "1.5rem", textAlign: "center", textDecoration: "underline" }}>See More</p></Link></div>

                    </div>

                    <div style={{ borderTop: "0.5px solid #000", marginLeft: "1.5rem", marginRight: "1.5rem", marginTop: 0 }}></div>

                    <div className="footer1" style={{ fontSize: "0.8rem" }}>
                        <p className="footer11">
                            63IDEAS INFOLABS PRRIVATE LIMITED Empire Parking, 9, We Work Vishnavi Signatur, No. 78/9, Outer Ring Road, Bellandur, Bengaluru, Bengaluru Urban, Karnataka, 560103
                        </p>

                        <p className="footer12">© 2023 63Ideas Infolabs Private Limited</p>
                    </div>

                    {/* <div style={{ paddingLeft: "10px", paddingRight: "10px" }}><Link to="https://drive.google.com/file/d/1kVUyklZ-pIo3oCAwDBGhHOf4D2YbzYJ7/view?usp=sharing"><p style={{ height: "50px", width: "100%", backgroundColor: "#F7F7F7", fontSize: "1.5rem", paddingTop: "20px", textAlign: "left", textDecoration: "underline" }}>List of Fruits Sellers</p></Link></div>

                    <div style={{ paddingLeft: "10px", paddingRight: "10px" }}><Link to="https://drive.google.com/file/d/1NT2kEIrE0U6fwwRf4iPgElUDW8HVLfFv/view?usp=share_link"><p style={{ height: "50px", width: "100%", backgroundColor: "#F7F7F7", fontSize: "1.5rem", paddingTop: "20px", textAlign: "left", textDecoration: "underline" }}>List of Vegetables Sellers</p></Link></div> */}


                </div>
            </div>
            <Footer />
        </div >
    )
}

export default Home
// export { ans, dd, mm, yy };