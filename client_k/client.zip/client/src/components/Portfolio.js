import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
// import leftarrow from './images/leftarrow.png';
// import search from './images/search.png';
// import shopname from './images/shopname.jpg';
// import personimg from './images/personimg.png';
// import image1 from './images/image1.jpg'
import shopfavicon from './images/shopfavicon.png';
import "./portfolio.css";

function getFileIdFromUrl(url) {
    const match = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
}

const Portfolio = () => {
    const { shopno } = useParams();
    const [companyData, setCompanyData] = useState(new Map());
    // const [name, setname] = useState(null);
    // const [vendorName, setvendorName] = useState(null);
    // const [shopPhoto, setshopPhoto] = useState(null);
    // const [vendorPhoto, setvedorPhoto] = useState(null);
    // const [shop1No, setshopNo] = useState(null);
    // const [mobileNo, setMobileNo] = useState(null);
    // const [dir, setdir] = useState(null);

    //for refresh page and immediate display
    useEffect(() => {
        async function fetchData() {
            const myMap = new Map();
            // const response = await fetch(`https://ninja-kirana.onrender.com/items/shopno/${shopno}`);
            const response = await fetch(`https://ninja-kirana.onrender.com/items/shopno/${shopno}`);
            const data = await response.json();
            // const url1 = data[0][10];
            // const url2 = data[0][11];
            // const nn = data[0][1];
            // const vn = data[0][12];
            // const imgid1 = getFileIdFromUrl(url1);
            // const imgid2 = getFileIdFromUrl(url2);
            // const shopid = data[0][2];
            // const dirid = data[0][3];
            // const mobileid = data[0][9];
            for (let i = 0; i < data.length; i++) {
                const key1 = data[i][1];
                //category price shopimg personimg mobileno direction shopno vendorname
                let matrix1 = [[data[i][9], data[i][10], data[i][4], data[i][5], data[i][12], data[i][3], data[i][2], data[i][6]]];
                if (data[i][9] === "") {
                    matrix1 = [[data[i][8], data[i][10], data[i][4], data[i][5], data[i][12], data[i][3], data[i][2], data[i][6]]];
                }
                const keyExists = myMap.has(key1);
                if (keyExists) {
                    const matrix2 = myMap.get(key1);
                    const matrix1With3 = matrix2.concat(matrix1);
                    myMap.set(key1, matrix1With3);
                }
                else {
                    myMap.set(key1, matrix1);
                }
            }
            setCompanyData(myMap);
            // setshopPhoto(imgid1);
            // setvedorPhoto(imgid2);
            // setshopNo(shopid);
            // setdir(dirid);
            // setMobileNo(mobileid);
            // setname(nn);
            // setvendorName(vn);
        }
        fetchData();
    }, []);

    const handleShare = () => {
        const url = window.location.href;
        const encodedUrl = encodeURIComponent(url);
        const caption = "Check out the portfolio: ";
        const encodedCaption = encodeURIComponent(caption);
        const whatsappUrl = `https://wa.me/?text=${encodedCaption}${encodedUrl}`;
        window.open(whatsappUrl, '_blank');
    };

    return (
        <>
            {/* <a href="whatsapp://send?text=Check out this website: [http://localhost:3000/Dryportfolio/276]" target="_blank">
                Share on WhatsApp
            </a> */}
            <link
                rel="stylesheet"
                href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
            />

            {/* <div className="fruits">
                <p className="centered">Fruits</p>
            </div> */}

            {/* <p>Hello</p> */}
            {/* console.log({companyData}); */}
            <div>
                {
                    Array.from(companyData).map(([companyName, productDetails]) => (
                        <div>
                            <p className='companyname'>{companyName}</p>

                            <div className="cover-photo-container">
                                <img className="shopname" src={`https://drive.google.com/uc?export=view&id=${getFileIdFromUrl(productDetails[0][2])}`} alt="shopphoto" />

                                <div className="profile-photo-container">
                                    <img className="profilephoto" src={`https://drive.google.com/uc?export=view&id=${getFileIdFromUrl(productDetails[0][3])}`} alt="personimg" />
                                    <p className="propname">{productDetails[0][7]}</p>
                                </div>

                                <div className="shopdist">

                                    <div className="shopdiv1">
                                        <img className="shopfavicon" src={shopfavicon} alt="shopfavicon" />
                                        <p style={{ fontWeight: 500, }}> Shop No: {productDetails[0][6]}</p>
                                    </div>

                                    <div className="shopdiv2">
                                        <p style={{ fontWeight: 500, }}>Jadhav Wadi Mandi </p>
                                    </div>

                                </div>

                            </div>

                            <div className="btn1">
                                <button className="btn" style={{ backgroundColor: "#fff", borderRadius: "5px", height: 32, width: "100%", borderWidth: "2px", borderColor: "#1D3A70", borderStyle: "solid" }}>
                                    <i className="fas fa-phone" style={{ color: "#1D3A70" }} />
                                    <a
                                        href={`tel:${productDetails[0][4]}`}
                                        style={{ color: "#1D3A70", textDecoration: "none" }}
                                    >
                                        &nbsp;&nbsp;Call Now
                                    </a>
                                </button>
                            </div>

                            <div className="card-body w-100" style={{ maxHeight: "1000px", overflow: "auto" }}>
                                <table className="table">
                                    <tbody>
                                        {productDetails.map((details) => (
                                            <tr key={details}>
                                                <td className="tableleft" style={{ fontFamily: "'Poppins', sans-serif" }}>
                                                    {details[0]}
                                                </td>
                                                <td className="tableright" style={{ fontFamily: "'Poppins', sans-serif" }}>
                                                    {details[1]}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* footer */}
                            <div className="card-footer w-100" style={{ height: 40, paddingTop: "-10px", paddingLeft: "5px", paddingRight: "5px", backgroundColor: "white", border: 0, position: "fixed", bottom: 0, }}>
                                <button className="btn w-50" style={{ backgroundColor: "#2C2C2C", borderRadius: 0, height: 32, width: "50%", border: 0, }}>
                                    <i className="fas fa-location-arrow" style={{ color: "white" }} />
                                    <a href={productDetails[0][5]} style={{ color: "white", textDecoration: "none" }}                                    >
                                        &nbsp;&nbsp;Directions
                                    </a>
                                </button>

                                <button onClick={handleShare} className="btn w-50" style={{ backgroundColor: "#19B44A", borderRadius: 0, height: 32, width: "50%", border: 0, }}>
                                    <i className="fab fa-whatsapp" style={{ color: "white" }} />
                                    <span style={{ color: "white", textDecoration: "none" }}>
                                        &nbsp;&nbsp;Share Profile
                                    </span>
                                </button>
                            </div>

                        </div>
                    ))}
            </div>
        </>
    )
}

export default Portfolio