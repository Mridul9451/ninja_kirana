import React, { useState, useEffect } from 'react';
import "./sellers.css";
import sellerslist from './images/sellerslist.png';
import { Link, useNavigate } from 'react-router-dom';
import arrowright from './images/arrowright.png';
import Portfolio from './Portfolio';


const Sellers = () => {
  const [companyData, setCompanyData] = useState(new Map());
  useEffect(() => {
    async function fetchData() {
      // someVarName = localStorage.getItem("date");
      const myMap = new Map();
      const response = await fetch(`https://ninja-kirana.onrender.com/items/all/all`);
      const data = await response.json();
      // console.log(data);
      for (let i = 0; i < data.length; i++) {
        // if (data[i][2] === someVarName) {
        const key1 = data[i][1];

        let matrix1 = [[data[i][2]], [data[i][7]]];
        const keyExists = myMap.has(key1);
        if (keyExists) {
          const matrix2 = myMap.get(key1);
          let c = 0;
          for (let j = 0; j < matrix2[1].length; j++) {
            if (matrix2[1][j] === matrix1[1][0]) {
              c = 1;
            }
          }
          if (c === 0) {
            const mat = [[data[i][2]], matrix2[1].concat(matrix1[1])];
            myMap.delete(key1);
            myMap.set(key1, mat);
          }
        }
        else {
          myMap.set(key1, matrix1);
        }
        // }
      }
      myMap.delete("Vendor Name");
      setCompanyData(myMap);
      // console.log(myMap);
    }
    fetchData();
  }, []);

  const [selectedId, setSelectedId] = useState(null);
  const handleButtonClick = (id) => {
    setSelectedId(id);
  };

  return (
    <div>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"></link>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'></link>
      <div style={{
        fontWeight: 600,
        fontSize: "1.625rem",
        paddingLeft: 20,
        color: "black",
        // backgroundImage: `url(${headerimg2})`,
        height: "10vh",
        margin: 0,
        display: 'block',
        backgroundRepeat: "repeat-x"
      }} className="d-flex align-items-center w-100 ninja">&nbsp;<img style={{ height: "2.5rem" }} src={sellerslist} alt="logo" />
        &nbsp;<p style={{ paddingTop: 10, fontFamily: "Poppins" }}>Sellers on ninja Kirana</p>
      </div>

      <div className='container-fluid'>
        {Array.from(companyData).map(([companyName, productDetails]) => (
          <div className="row" style={{ fontFamily: "Poppins", paddingLeft: 0, paddingRight: 0, marginBottom: "10px" }}>

            <div className="col-xs-5 col-sm-4 col-lg-6">
              <p style={{ lineHeight: "1rem", fontSize: "1rem", fontWeight: "600", paddingTop: "15px" }}>{companyName}</p>
              <p style={{ lineHeight: "1rem", fontSize: "1rem", fontWeight: "600" }}>Shop No. {productDetails[0]}</p>
            </div>

            <div className="col-xs-3 col-sm-2 col-lg-2">
              <p style={{ fontSize: "1rem", fontWeight: "600" }}>
                {productDetails[1][0]} {productDetails[1][1]}
              </p>
            </div>

            <div className="col-xs-4 col-sm-6 col-lg-4">
              <Link to={`/portfolio/${productDetails[0]}`}>
                <p style={{ fontSize: "1rem", textAlign: "right", color: "black", fontWeight: "600" }}>
                  <span style={{ textDecoration: "underline" }}>Know More</span>
                  &nbsp;&nbsp;
                  <img style={{ height: "1.5rem" }} src={arrowright} alt='arrowright'></img>
                </p>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Sellers
