import React from 'react';
import "./staple.css";
import Footer from './Footer';

const Staple = () => {
    return (
        <div>
            <div className='cont'>Coming Soon to Aurangabad!!</div>
            <Footer />
        </div>
    )
}

export default Staple