import React, { useState, useEffect } from 'react';
import Select from 'react-select';
import "./vegetable.css";
import Footer from './Footer';
// import { dd, mm, yy } from "./Home";

const Vegetable = () => {
    const [companyData, setCompanyData] = useState(new Map());

    // if (dd !== undefined) {
    //     localStorage.setItem("ds", dd);
    // }
    // let d = localStorage.getItem("ds");

    // if (mm !== undefined) {
    //     localStorage.setItem("ms", mm);
    // }
    // let m = localStorage.getItem("ms");

    // if (yy !== undefined) {
    //     localStorage.setItem("ys", yy);
    // }
    // let y = localStorage.getItem("ys");

    // if (m === "0") {
    //     d = d + " Jan " + y;
    // }
    // else if (m === "1") {
    //     d = d + " Feb " + y;
    // }
    // else if (m === "2") {
    //     d = d + " Mar " + y;
    // }
    // else if (m === "3") {
    //     d = d + " Apr " + y;
    // }
    // else if (m === "4") {
    //     d = d + " May " + y;
    // }
    // else if (m === "5") {
    //     d = d + " Jun " + y;
    // }
    // else if (m === "6") {
    //     d = d + " Jul " + y;
    // }
    // else if (m === "7") {
    //     d = d + " Aug " + y;
    // }
    // else if (m === "8") {
    //     d = d + " Sep " + y;
    // }
    // else if (m === "9") {
    //     d = d + " Oct " + y;
    // }
    // else if (m === "10") {
    //     d = d + " Nov " + y;
    // }
    // else {
    //     d = d + " Dec " + y;
    // }

    // localStorage.setItem("date", d);
    // var someVarName = localStorage.getItem("date");

    const [selectedOptions, setSelectedOptions] = useState();
    const optionList = [
        { value: "vegetable", label: "All" },
        { value: "bitter gourd", label: "Bitter Gourd" },
        { value: "capsicum", label: "Capsicum" },
        { value: "cauliflower", label: "Cauliflower" },
        { value: "chilli", label: "Chilli" },
        { value: "cucumber", label: "Cucumber" },
        { value: "fenugreek", label: "Fenugreek" },
        { value: "ladyfinger", label: "Ladyfinger" },
        { value: "lemon", label: "Lemon" },
        { value: "brinjal", label: "Brinjal" },
        { value: "garlic", label: "Garlic" },
        { value: "ginger", label: "Ginger" },
        { value: "green chilli", label: "Green Chilli" },
        { value: "onion", label: "Onion" },
        { value: "potato", label: "Potato" },
        { value: "tamarind", label: "Tamarind" },
        { value: "tomato", label: "Tomato" },
        { value: "zucchini", label: "Zucchini" },
        { value: "spinach", label: "Spinach" },
        { value: "runner bean", label: "Runner Bean" },
        { value: "cabbage", label: "Cabbage" }
    ];

    useEffect(() => {
        async function fetchData() {
            // someVarName = localStorage.getItem("date");
            const myMap = new Map();
            const response = await fetch("https://ninja-kirana.onrender.com/items/vegetable/all");
            const data = await response.json();
            for (let i = 0; i < data.length; i++) {
                // if (data[i][2] === someVarName) {
                const key1 = data[i][1];
                let matrix1 = [[data[i][2], data[i][3], data[i][9], data[i][10], data[i][12]]];
                if (data[i][9] === "") {
                    matrix1 = [[data[i][2], data[i][3], data[i][8], data[i][10], data[i][12]]];
                }
                const keyExists = myMap.has(key1);
                if (keyExists) {
                    const matrix2 = myMap.get(key1);
                    const matrix1With3 = matrix2.concat(matrix1);
                    myMap.set(key1, matrix1With3);
                }
                else {
                    myMap.set(key1, matrix1);
                }
                // }
            }
            setCompanyData(myMap);
        }
        fetchData();
    }, []);

    const handleSelect = async (data2) => {
        setSelectedOptions(data2);
        // someVarName = localStorage.getItem("date");
        const myMap = new Map();
        var x = 0;
        for (let i = 0; i < data2.length; i++) {
            if (data2[i].value === "vegetable") {
                x = 1;
            }
        }
        if (x === 1) {
            const response = await fetch(`https://ninja-kirana.onrender.com/items/vegetable/all`);
            const data = await response.json();
            for (let i = 0; i < data.length; i++) {
                // if (data[i][2] === someVarName) {
                const key1 = data[i][1];
                let matrix1 = [[data[i][2], data[i][3], data[i][9], data[i][10], data[i][12]]];
                if (data[i][9] === "") {
                    matrix1 = [[data[i][2], data[i][3], data[i][8], data[i][10], data[i][12]]];
                }
                const keyExists = myMap.has(key1);
                if (keyExists) {
                    const matrix2 = myMap.get(key1);
                    const matrix1With3 = matrix2.concat(matrix1);
                    myMap.set(key1, matrix1With3);
                }
                else {
                    myMap.set(key1, matrix1);
                }
                // }
            }
        }
        else {
            for (let i = 0; i < data2.length; i++) {
                const response = await fetch(`https://ninja-kirana.onrender.com/items/vegetable/${data2[i].value}`);
                const data = await response.json();
                for (let i = 0; i < data.length; i++) {
                    // if (data[i][2] === someVarName) {
                    const key1 = data[i][1];
                    let matrix1 = [[data[i][2], data[i][3], data[i][9], data[i][10], data[i][12]]];
                    if (data[i][9] === "") {
                        matrix1 = [[data[i][2], data[i][3], data[i][8], data[i][10], data[i][12]]];
                    }
                    const keyExists = myMap.has(key1);
                    if (keyExists) {
                        const matrix2 = myMap.get(key1);
                        const matrix1With3 = matrix2.concat(matrix1);
                        myMap.set(key1, matrix1With3);
                    }
                    else {
                        myMap.set(key1, matrix1);
                    }
                    // }
                }
            }
        }
        setCompanyData(myMap);
    }

    return (
        <>
            {/*for font awesome icons*/}
            <link
                rel="stylesheet"
                href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
            />
            <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'></link>
            <div className='mybody'>
                {/* <div className='selection'>Date: {d}</div>
                <br /> */}

                <div className="dropdown-container">
                    <Select
                        styles={{ fontFamily: "Poppins" }}
                        options={optionList}
                        placeholder="Select vegetable"
                        value={selectedOptions}
                        defaultValue={{ label: "All", value: "vegetable" }}
                        onChange={handleSelect}
                        isSearchable={true}
                        isMulti
                    />
                </div>

                <div className="card-container">
                    {Array.from(companyData).map(([companyName, productDetails]) => (
                        <div className="cat_cards" style={{ paddingTop: 1 }}>
                            <div
                                style={{ width: 400, alignItems: "center" }}
                                className="card mx-auto"
                            >
                                <div className="card-header w-100 row" style={{ height: 35 }} key={companyName}>
                                    <p style={{ fontWeight: 700, fontFamily: "Poppins" }}>{companyName}</p>
                                </div>
                                <br />
                                <div>
                                    <button
                                        className="shop_no"
                                        style={{
                                            float: "right",
                                            backgroundColor: "#F2C652",
                                            color: "black",
                                            border: "none",
                                            fontFamily: "Poppins"
                                        }}
                                    >
                                        <i className="fas fa-store" style={{ color: "black" }} />
                                        &nbsp;&nbsp;Shop No - {productDetails[0][0]}
                                    </button>
                                </div>

                                <div className="card-body w-100" style={{ maxHeight: "1000px", overflow: "auto" }}>
                                    <table className="table">
                                        <tbody>
                                            {productDetails.map((details) => (
                                                <tr key={details}>
                                                    <td className="tableleft" style={{ fontFamily: "Poppins" }}>
                                                        {details[2]}
                                                    </td>
                                                    <td className="tableright" style={{ fontFamily: "Poppins" }}>
                                                        {details[3]}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="card-footer w-100" style={{ height: 40 }}>
                                    <button className="btn" style={{ backgroundColor: "#19B44A", fontFamily: "Poppins" }}>
                                        <i className="fas fa-phone" style={{ color: "white" }} />
                                        <a href={`tel:${productDetails[0][4]}`} style={{ color: "white", textDecoration: "none" }}>
                                            &nbsp;&nbsp;Call Owner
                                        </a>
                                    </button>
                                    <button className="btn" style={{ backgroundColor: "#DADADA", fontFamily: "Poppins" }}>
                                        <i className="fas fa-location-arrow" style={{ color: "black" }} />
                                        <a
                                            href={productDetails[0][1]}
                                            style={{ color: "black", textDecoration: "none" }}
                                        >
                                            &nbsp;&nbsp;Directions
                                        </a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Vegetable